error_single <- function(obs_df){
  n <- nrow(obs_df)
  testing_num <- sample(1:n, .25*n, replace = FALSE)
  coeff <- .lm.fit(cbind(1, obs_df$X1[-testing_num], obs_df$X2[-testing_num]), obs_df$Y[-testing_num])$coef
  mean((obs_df$Y[testing_num] - coeff[1] - obs_df$X1[testing_num] * coeff[2] - obs_df$X2[testing_num] * coeff[3])**2)
}

mse_single <- function(obs_df, R_num)
  do.call(c,lapply(1:R_num, function(u) error_single(obs_df)))


error_single2 <- function(obs_df, testing_num){
  coeff <- .lm.fit(cbind(1, obs_df$X1[-testing_num], obs_df$X2[-testing_num]), obs_df$Y[-testing_num])$coef
  mean((obs_df$Y[testing_num] - coeff[1] - obs_df$X1[testing_num] * coeff[2] - obs_df$X2[testing_num])**2)
}