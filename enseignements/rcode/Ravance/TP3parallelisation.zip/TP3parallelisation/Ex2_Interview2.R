rm(list=ls())
source("Ex2_Onesampling.R")
require(parallel)
require(profvis)

reps <- 10**4
n <- 100
beta0 <- 2
beta1 <- .7

set.seed(123)
p <- profvis({
  save <- vector()
  for (i in 1:reps) {
    obs_ls <- oneSampling(n, beta0, beta1)
    coef <- .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef
    save <- c(save, coef)
  }
  save <- data.frame(save)
})
htmltools::save_html(p, file = "Ex2_ProfilingTime2.html", libdir = "profiling/") 
