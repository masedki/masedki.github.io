rm(list=ls())
set.seed(123)
require(parallel)
require(profvis)
source("Ex3_sampling.R")
source("Ex3_singlecore.R")

n <- 100
R <- 2000

nbCPU <- 30
ech_df <- robs (n)

cl <- makeCluster(nbCPU)
clusterExport(cl, "ech_df")
clusterExport(cl, "error_single")
parSapply(cl, 1:R, function(u) error_single(ech_df))
stopCluster(cl)
