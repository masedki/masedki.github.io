rm(list=ls())
require(parallel)
require(profvis)

robs <- function(n, d) matrix(rnorm(n*d), n, d)

set.seed(123)
n <- 10**4
d <- 5
N <- 200
allobs_ls <- replicate(N, robs(n, d), simplify = F)


p <- profvis({
mean.w1 <- matrix(0, N, d)
for (s in 1:N)  mean.w1[s,] <- colMeans(allobs_ls[[1]])
mean.w2 <- do.call(rbind, lapply(allobs_ls, colMeans))
mean.w3 <- t(sapply(allobs_ls, colMeans))
})
p

detectCores()

system.time(meancol <- do.call(rbind, lapply(allobs_ls, colMeans)))
system.time(meancol2 <- do.call(rbind, mclapply(allobs_ls, colMeans, mc.cores = 2)))
system.time(meancol2 <- do.call(rbind, mclapply(allobs_ls, colMeans, mc.cores = 10)))
system.time(meancol3 <- do.call(rbind, mclapply(allobs_ls, colMeans, mc.cores = 20)))

system.time(meancol <- lapply(allobs_ls, summary, centers=2))
system.time(meancol2 <- mclapply(allobs_ls, summary, centers=2, mc.cores = 2))
system.time(meancol2 <- mclapply(allobs_ls, summary, centers=2, mc.cores = 10))
system.time(meancol3 <- mclapply(allobs_ls, summary, centers=2, mc.cores = 20))

 
