require(bench)
rm(list=ls())
source("Ex2_Onesampling.R")

set.seed(123)
# Copy the data generating code:
obs_ls <- oneSampling(100, 2, .7)

mbm <- mark(lm={as.numeric(lm(obs_ls$y_num ~ obs_ls$x_num+0)$coefficients)},
            direct= as.numeric(solve(t(obs_ls$x_num) %*% obs_ls$x_num) %*% (t(obs_ls$x_num) %*% obs_ls$y_num)),
            interne= {.lm.fit(as.matrix(obs_ls$x_num), obs_ls$y_num)$coefficients})
plot(mbm)

