rm(list=ls())
source("Ex3_sampling.R")
source("Ex3_singlecore.R")
source("Ex3_forking.R")

set.seed(123)
ech_df <- robs(1000)
system.time(mse_single(ech_df, 200))
system.time(mse_forking(ech_df, 200, 34))
system.time(mse_forking2(ech_df, 200, 34))



