rm(list=ls())
source("Ex2_Onesampling.R")
require(parallel)
require(profvis)

reps <- 10**4
n <- 100
beta0 <- 2
beta1 <- .7

p <- profvis({
  set.seed(123)
  save <- rep(NA, reps)
  for (i in 1:reps) {
    obs_ls <- oneSampling(n, beta0, beta1)
    save[i] <- .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef[2]
  }

  set.seed(123)
  save2 <-  sapply(1:reps, function(u) {
    obs_ls <- oneSampling(n, beta0, beta1)
    .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef[2]
  })
})
p
htmltools::save_html(p, "Ex2_ProfilingTime4.html") 

# p <- mark(loop={
#   set.seed(123)
#   save <- rep(NA, reps)
#   for (i in 1:reps) {
#     obs_ls <- oneSampling(n, beta0, beta1)
#     save[i] <- .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef[2]
#   }
#   save},
#   sapply={
#   set.seed(123)
#   save <-  sapply(1:reps, function(u) {
#     obs_ls <- oneSampling(n, beta0, beta1)
#     .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef[2]
#   })
#   save},filter_gc = F
# )
# plot(p)
