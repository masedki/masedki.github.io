rm(list=ls())
source("Ex2_Onesampling.R")
require(parallel)
require(profvis)

reps <- 10**4
n <- 1000
beta0 <- 2
beta1 <- .7

set.seed(123)
out <- list()
system.time({
  save <- rep(NA, reps)
  for (i in 1:reps) {
    obs_ls <- oneSampling(n, beta0, beta1)
    save[i] <- .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef[2]
  }}
)

# With random sampling on multi-cores

nbCPU <- 10
set.seed(123)
system.time({
save2 <-  unlist(mclapply(1:reps, function(u) {
  obs_ls <- oneSampling(n, beta0, beta1)
  .lm.fit(cbind(1, obs_ls$x_num), obs_ls$y_num)$coef[2]
}, mc.cores = nbCPU))
})

# No random sampling on multi-cores

nbCPU <- 10
set.seed(123)
system.time({
allech_ls <- replicate(reps,  oneSampling(n, beta0, beta1), simplify = F)
save3 <- unlist(mclapply(allech_ls,
                         function(obs)   .lm.fit(cbind(1, obs$x_num), obs$y_num)$coef[2]))
})

all.equal(save, save2)
all.equal(save, save3)

