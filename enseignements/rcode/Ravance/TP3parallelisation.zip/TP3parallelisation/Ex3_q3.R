rm(list=ls())
source("Ex3_sampling.R")
source("Ex3_singlecore.R")

set.seed(123)
ech_df <- robs(1000)
mse_single(ech_df, 200)
