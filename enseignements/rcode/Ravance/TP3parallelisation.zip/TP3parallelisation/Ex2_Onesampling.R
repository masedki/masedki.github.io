oneSampling <- function(n, beta0, beta1){
  x_num <- rnorm(n)
  y_num <- beta0 + beta1*x_num + rnorm(n)
  badinterviewer <- sample(1:n, .25*n, replace = FALSE)
  x_num[badinterviewer] <- ceiling(x_num[badinterviewer])
  list(x_num=x_num, y_num=y_num)
}
