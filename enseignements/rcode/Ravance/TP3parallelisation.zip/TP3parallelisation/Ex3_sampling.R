robs <- function(n, alpha=2, beta=rep(1, 2)){
  x <- matrix(rnorm(n * 2), n, 2)
  data.frame(Y = as.numeric(alpha + x%*%beta + rnorm(n)), X1=x[,1], X2=x[,2])
}