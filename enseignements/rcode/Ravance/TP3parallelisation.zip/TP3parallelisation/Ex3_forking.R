mse_forking <- function(ech_df, R, nbCPU)
  do.call(c, mclapply(1:R, function(u) error_single(obs_df =  ech_df), mc.cores = nbCPU))

mse_forking2 <- function(ech_df, R, nbCPU){
  n <- nrow(ech_df)
  testing_ls <- replicate(R, sample(1:n, .25*n, replace = FALSE), simplify = FALSE)
  do.call(c, mclapply(testing_ls, function(test) error_single2(obs_df =  ech_df, testing_num = test), mc.cores = nbCPU))
}


mse_multi_forking1 <- function(allech_ls, R, nbCPU){
  lapply(allech_ls, function(ech) mclapply(1:R, function(u) error_single(obs_df =  ech), mc.cores = nbCPU))
}

mse_multi_forking2 <- function(allech_ls, R, nbCPU){
  N <- length(allech_ls)
  echlabel_num <- rep(1:N, each = R)
  testing_ls <- lapply(echlabel_num, function(i){
    n <- nrow(allech_ls[[i]])
    sample(1:n, .25*n, replace = FALSE)
  }
  )
  do.call(c, mclapply(1:(R*N), function(i) error_single2(allech_ls[[echlabel_num[i]]], testing_ls[[i]])))
}
