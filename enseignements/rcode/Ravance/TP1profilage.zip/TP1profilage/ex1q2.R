source("ex1q1.R")
res.prof <- profvis(expr = {
  datanew_df <- data_df
  meancol <- apply(data_df[, names(data_df) != "ID"], 2, mean)
  for (j in seq_along(meancol)) {
    datanew_df[, names(datanew_df) != "ID"][, j] <- datanew_df[, names(datanew_df) != "ID"][, j] - meancol[j]
  }
}
)

htmltools::save_html(res.prof, file = "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex1q2.html") 

