rm(list=ls())
require(profvis)
set.seed(123)

n_int <- 10**4
d_int <- 20

data_df <- matrix(rnorm(n_int * d_int), n_int, d_int)
data_df[data_df>2] <- NA
