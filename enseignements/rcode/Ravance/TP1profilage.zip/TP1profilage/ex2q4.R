source("ex2q3.R")

method3 <- function(data_df){
  csum <- function(x_num) {
    if (length(x_num) < 2)
      return(x_num)
    
    out_num <- rep(x_num[1], length(x_num))
    for (i in 2:length(x_num)) 
      out_num[i] <- out_num[i-1] + x_num[i]
    
    out_num
  }
  data_df$sum <- csum(data_df$value)
  data_df
}

res.prof <- profvis(method2(data_df))

htmltools::save_html(res.prof, file = "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex2q4.html") 

# Pour comparer les deux methodes
data_df <- data.frame(value=runif(10^6))

T2 <- Sys.time()
tmp2 <- method2(data_df)
T3 <- Sys.time()
tmp3 <- method3(data_df)
T4 <- Sys.time()
all.equal(tmp2, tmp3)
difftime(T3, T2)
difftime(T4, T3)
