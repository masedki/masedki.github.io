source("ex2q1.R")

method2 <- function(data_df){
  csum <- function(x_num) {
    if (length(x_num) < 2)
      return(x_num)
    
    out_num <- x_num[1]
    for (i in 2:length(x_num)) 
      out_num[i] <- out_num[i-1] + x_num[i]
    
    out_num
  }
  data_df$sum <- csum(data_df$value)
  data_df
}

res.prof <- profvis(method2(data_df))

htmltools::save_html(res.prof, file = "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex2q3.html") 

# Pour comparer les deux methodes
T1 <- Sys.time()
tmp1 <- method1(data_df)
T2 <- Sys.time()
tmp2 <- method2(data_df)
T3 <- Sys.time()

difftime(T2, T1)
difftime(T3, T2)
