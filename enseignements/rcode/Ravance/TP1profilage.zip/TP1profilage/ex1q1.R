rm(list=ls())
require(profvis)
require(bench)
set.seed(123)

n_int <- 10**5
d_int <- 150
data_df <- cbind.data.frame(ID=paste("g", 1:n_int, sep = "."),
                         matrix(rnorm(n_int * d_int), n_int, d_int))
