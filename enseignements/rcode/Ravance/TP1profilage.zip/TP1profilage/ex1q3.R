source("ex1q1.R")

res.prof <- profvis({
  datanew_df <- data_df
  # Four different ways of getting column means
  meancol <- apply(datanew_df[, names(datanew_df) != "ID"], 2, mean)
  meancol <- colMeans(datanew_df[, names(datanew_df) != "ID"])
  meancol <- as.numeric(lapply(datanew_df[, names(datanew_df) != "ID"], mean))
  meancol <- vapply(datanew_df[, names(datanew_df) != "ID"], mean, numeric(1))
})


htmltools::save_html(res.prof, "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex1q3.html") 

# Les deux dernieres methodes sont les meilleures. On peut utiliser le microbenchmark

res.micro <- mark(apply(datanew_df[, names(datanew_df) != "ID"], 2, mean),
                  colMeans(datanew_df[, names(datanew_df) != "ID"]),
                  unlist(lapply(datanew_df[, names(datanew_df) != "ID"], mean)),
                  vapply(datanew_df[, names(datanew_df) != "ID"], mean, numeric(1)), filter_gc = F)
plot(res.micro)

res.micro <- mark(unlist(lapply(datanew_df[, names(datanew_df) != "ID"], mean)),
                  vapply(datanew_df[, names(datanew_df) != "ID"], mean, numeric(1)), filter_gc = F)
plot(res.micro)
