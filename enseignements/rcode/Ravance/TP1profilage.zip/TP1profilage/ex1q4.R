source("ex1q1.R")
res.prof <- profvis(expr = {
  datanew_df <- data_df
  meancol <- vapply(datanew_df[, names(datanew_df) != "ID"], mean, numeric(1))
  for (i in seq_along(meancol)) {
    datanew_df[, names(datanew_df) != "ID"][, i] <- datanew_df[, names(datanew_df) != "ID"][, i] - meancol[i]
  }
}
)

htmltools::save_html(res.prof, "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex1q4.html") 

