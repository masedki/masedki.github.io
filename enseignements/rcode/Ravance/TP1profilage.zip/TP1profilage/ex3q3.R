source("ex3q1.R")
source("ex3q2.R")

res.prof <- profvis(expr = {
  res1 <- funAgg(data_df)
  res2 <- funLoop(data_df)
  res3 <- funApply(data_df)
  res4 <- funOmit(data_df)
})

htmltools::save_html(res.prof, "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex3q3.html") 

