source("ex2q1.R")
res.prof <- profvis(expr = method1(data_df))

htmltools::save_html(res.prof, file = "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex2q2.html") 

