source("ex1q1.R")
res.prof <- profvis(expr = {
  datanew_df <- data_df
  datanew_df[, names(datanew_df) != "ID"] <-  lapply(datanew_df[, names(datanew_df) != "ID"], function(u) u - mean(u))
})

htmltools::save_html(res.prof, "~/Dropbox/enseignement/r_parallel/fichesTP/TP1-codemonitoring/TP1profilage/profilageoutputs/ex1q5.html") 

