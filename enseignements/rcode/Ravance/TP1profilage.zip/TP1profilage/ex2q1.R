rm(list=ls())
require(profvis)
set.seed(123)

n_int <- 3 * (10**4)

data_df <- data.frame(value=runif(n_int))

method1 <- function(data_df){
  data_df$sum[1] <- data_df$value[1]
  for (i in 2:n_int) 
    data_df$sum[i] <- data_df$sum[i-1] + data_df$value[i]
  data_df
}
