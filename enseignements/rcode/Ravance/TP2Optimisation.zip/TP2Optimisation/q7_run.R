rm(list=ls())
source("q1_fctsksmooth.R")
source("cv_fcts.R")
source("density_fcts.R")

nvals_num <- c(25, 50, 100, 200, 400, 800)
pw_num <- -1/(2:7)
nbrep_num <- 10

allech_ls <- lapply(nvals_num, function(n) replicate(10, rt(n, 2), simplify = FALSE))

results_mat <- matrix(0, length(nvals_num), nbrep_num)
i <- 0
for (n in nvals_num){
  i <- i + 1
  tmp <- lapply(allech_ls[[i]], mydensitySapply, xpts_num=0, hvals_num=n^pw_num)
  results_mat[i,] <- sapply(tmp, function(u) u$band)
}
save(results_mat, nvals_num, pw_num, file = "resultsq7.rda")
