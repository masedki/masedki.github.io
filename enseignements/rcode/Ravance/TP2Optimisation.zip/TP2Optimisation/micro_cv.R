rm(list=ls())
source("q1_fctsksmooth.R")
source("cv_fcts.R")
require(bench)
set.seed(123)
ech_num <- rt(1000, df = 2)

res <- mark(basic = basic_cv(ech_num, 0.337),
            optim1 = optim1_cv(ech_num, 0.337),
            optim2 = optim2_cv(ech_num, 0.337),
            best = best_cv(ech_num, 0.337), filter_gc = F)
plot(res)
