ksmooth1 <- function(x_num, xpts_num, h_num=length(x_num)**(-1/5)){
  dens_num <- rep(0, length(xpts_num))
  n_num <- length(x_num)
  for(i in 1:length(xpts_num)) {
    ksum <- 0
    for(j in 1:n_num) {
      d <- xpts_num[i] - x_num[j]
      ksum <- ksum + dnorm(d / h_num)
    }
    dens_num[i] <- ksum / (n_num * h_num)
  }
  dens_num
}

ksmooth2 <- function(x_num, xpts_num, h_num=length(x_num)**(-1/5)){
  n_num <- length(x_num)
  D_mat <- outer(x_num, xpts_num, "-")
  K_mat <- dnorm(D_mat / h_num)
  colSums(K_mat) / (h_num * n_num)
}

ksmooth3 <- function(x_num, xpts_num, h_num=length(x_num)**(-1/5)){
  n_num <- length(x_num)
  dens_num <- rep(0, length(xpts_num))
  for (i in 1:length(xpts_num)) {
    dens_num[i] <- sum(dnorm((xpts_num[i] - x_num)/h_num))
  }
  dens_num / (n_num * h_num)
}

ksmooth4 <-  function(x_num, xpts_num, h_num=length(x_num)**(-1/5)){
  n_num <- length(x_num)
  sapply(xpts_num,
         function(xpts_i)
           sum(dnorm((xpts_i - x_num)/h_num))
  )/ (n_num * h_num)
}