basic_cv <- function(x_num, h_num){
  # Calcul de l'integrale de \hat{f}^2_n
  res.hatfsquare <- 0
  for (i in 1:length(x_num))
    res.hatfsquare <- res.hatfsquare + ksmooth3(x_num, x_num[i], h_num * sqrt(2))
  res.hatfsquare <- res.hatfsquare / length(x_num)
  # Calcul de \hat_f_{h,(-i)}
  res.hatfiremove <- NULL
  for (i in 1:length(x_num))
    res.hatfiremove <- c(res.hatfiremove,
                         2 * ksmooth3(x_num[-i], x_num[i], h_num) / length(x_num))
  # Calcul de CV
  CV <- res.hatfsquare - sum(res.hatfiremove)
  return(CV)
}

# Version optimisee sur l'intergrale
optim1_cv <- function(x_num, h_num){
  n_num <- length(x_num)
  # Calcul de l'integrale de \hat{f}^2_n
  res.hatfsquare <- 0
  for (xi in x_num)    res.hatfsquare <- res.hatfsquare + sum(dnorm( (xi - x_num) / (sqrt(2)*h_num)))
  res.hatfsquare <- res.hatfsquare/(n_num*n_num*(sqrt(2)*h_num))
  
  # Calcul de \hat_f_{h,(-i)}
  res.hatfiremove <- NULL
  for (i in 1:n_num)
    res.hatfiremove <- c(res.hatfiremove,  2 * ksmooth3(x_num[-i], x_num[i], h_num) / length(x_num))
  # Calcul de CV
  CV <- res.hatfsquare - sum(res.hatfiremove)
  return(CV)
}

# Version optimisee en enlevant objets de taille croissante
optim2_cv <- function(x_num, h_num){
  n_num <- length(x_num)
  # Calcul de l'integrale de \hat{f}^2_n
  res.hatfsquare <- sum(sapply(x_num, function(u) sum(dnorm( (u - x_num) / (sqrt(2)*h_num))))) / (n_num*n_num*(sqrt(2)*h_num))
  # Calcul de \hat_f_{h,(-i)}
  res.hatfiremove <- sum(2 * sapply(1:n_num, function(i) ksmooth3(x_num[-i], x_num[i], h_num) ) / n_num)
  CV <- res.hatfsquare - sum(res.hatfiremove)
  return(CV)
}

# Meilleure version car en considere qu'une boucle et la symmetrie du noyaux
best_cv <- function(x_num, h_num){
  n_num <- length(x_num)
  fhat.full.hat <- 0
  for(i in 1:(n_num-1)) {
    diff <- (x_num[i] - x_num[(i+1):n_num])
    fhat.full.hat <- fhat.full.hat + 2 * sum(dnorm(diff, 0, sqrt(2)*h_num))/n_num - 4 * sum(dnorm(diff/h_num))/((n_num-1)*h_num)
  }
  fhat.full.hat <- fhat.full.hat + dnorm(0, 0, sqrt(2)*h_num)
  fhat.full.hat / n_num
}