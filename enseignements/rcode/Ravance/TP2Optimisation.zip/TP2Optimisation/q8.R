mydensitySapply_diffusable <- function(x_num, xpts_num=x_num, hvals_num=length(x_num)**(-1/5)){
  if (class(x_num)!="numeric") stop("x_num doit etre numeric")
  if (class(xpts_num)!="numeric") stop("xpts_num doit etre numeric")
  if (class(hvals_num)!="numeric") stop("hvals_num doit etre numeric")
  if (any(hvals_num>0)){
    warnings("hvals_num en valeurs absolues")
    hvals_num <- abs(hvals_num)
  }   
  all.cv <- sapply(hvals_num, best_cv, x=x_num)
  best.band <- hvals_num[which.min(all.cv)]
  list(band = best.band,
       cv = min(all.cv),
       density = ksmooth3(x_num, xpts_num, best.band))
}
