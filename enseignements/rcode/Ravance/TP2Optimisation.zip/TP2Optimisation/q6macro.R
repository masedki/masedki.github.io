rm(list=ls())
source("q1_fctsksmooth.R")
source("cv_fcts.R")
source("density_fcts.R")
require(bench)
require(profvis)
set.seed(123)
ech_num <- rt(1000, df = 2)

resvis <- profvis({
  res <- basic_mydensity(ech_num, seq(-4, 4, length.out = 100), length(ech_num)**(1/(2:7)))
})

resvis

resvis2 <- profvis({
  res <- basic_mydensity(ech_num, seq(-4, 4, length.out = 100), length(ech_num)**(1/(2:7)))
  res2 <- mydensitySapply(ech_num, seq(-4, 4, length.out = 100), length(ech_num)**(1/(2:7)))
})

resvis2
