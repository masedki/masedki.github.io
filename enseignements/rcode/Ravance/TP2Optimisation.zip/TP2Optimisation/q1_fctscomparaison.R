compareksmooth12_macro <- function(nsample_num, nevals_num){
  ech_num <- rnorm(nsample_num)
  profvis({
    res_ksmooth1 <- ksmooth1(ech_num, seq(-4, 4, length.out = nevals_num))
    res_ksmooth2 <- ksmooth2(ech_num, seq(-4, 4, length.out = nevals_num))
  })
}

compareksmoothall_macro <- function(nsample_num, nevals_num){
  ech_num <- rnorm(nsample_num)
  profvis({
    res_ksmooth1 <- ksmooth1(ech_num, seq(-4, 4, length.out = nevals_num))
    res_ksmooth2 <- ksmooth2(ech_num, seq(-4, 4, length.out = nevals_num))
    res_ksmooth3 <- ksmooth3(ech_num, seq(-4, 4, length.out = nevals_num))
    res_ksmooth4 <- ksmooth4(ech_num, seq(-4, 4, length.out = nevals_num))
  })
}

compareksmooth12_micro <- function(nsample_num, nevals_num){
  ech_num <- rnorm(nsample_num)
  micro <- mark(res_ksmooth1 = ksmooth1(ech_num, seq(-4, 4, length.out = nevals_num)),
                res_ksmooth2 = ksmooth2(ech_num, seq(-4, 4, length.out = nevals_num))
  )
  micro
}

compareksmoothall_micro <- function(nsample_num, nevals_num){
  ech_num <- rnorm(nsample_num)
  micro <- mark(res_ksmooth1 = ksmooth1(ech_num, seq(-4, 4, length.out = nevals_num)),
                res_ksmooth2 = ksmooth2(ech_num, seq(-4, 4, length.out = nevals_num)),
                res_ksmooth3 = ksmooth3(ech_num, seq(-4, 4, length.out = nevals_num)),
                res_ksmooth4 = ksmooth4(ech_num, seq(-4, 4, length.out = nevals_num))
  )
  micro
}