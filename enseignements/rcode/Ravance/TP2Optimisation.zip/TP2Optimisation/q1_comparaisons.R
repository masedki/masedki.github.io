rm(list=ls())
require(bench)
require(profvis)
source("q1_fctsksmooth.R")
source("q1_fctscomparaison.R")

# question c
set.seed(123)
res_macro <- compareksmooth12_macro(10**4, 17)
res_micro <- compareksmooth12_micro(10**4, 17)

# question d
ech_num <- rnorm(10**7)
resprof <- profvis({
  res_ksmooth2 <- ksmooth2(ech_num, seq(-4, 4, length.out = 10**7))
})

# question g
res_macro <- compareksmoothall_macro(10**4, 17)
res_micro <- compareksmoothall_micro(10**4, 17)