
basic_mydensity <- function(x_num, xpts_num, hvals_num){
  cv_num <- rep(0, length(hvals_num))
  results_ls <- list()
  cp <- 0
  for (h in hvals_num){
    cp <- cp + 1
    cv_num[cp] <- basic_cv(x_num, h)
    results_ls[[cp]] <- ksmooth3(x_num, xpts_num, h)
  }
  list(band=hvals_num[[which.min(cv_num)]],
       cv=min(cv_num),
       density=results_ls[[which.min(cv_num)]])
}

mydensitySapply <- function(x_num, xpts_num, hvals_num){
  all.cv <- sapply(hvals_num, best_cv, x=x_num)
  best.band <- hvals_num[which.min(all.cv)]
  list(band = best.band,
       cv = min(all.cv),
       density = ksmooth3(x_num, xpts_num, best.band))
}
