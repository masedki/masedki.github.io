rm(list=ls())
source("q1_fctsksmooth.R")
source("cv_fcts.R")

set.seed(123)
hvals <- c(0.05, 0.337, 2)
ech_num <- rt(100, df = 2)
grid_num <- seq(min(ech_num), max(ech_num), length.out = 500)
results <- sapply(hvals, ksmooth4, x_num = ech_num, xpts_num = grid_num)

pdf("q2_bandwithStudent.pdf")
plot(grid_num, dt(grid_num, 2), type="l", ylim=range(results))
for (i in 1:length(hvals))
  lines(grid_num, results[,i], col=i+1)
legend("topright", c("true", paste("h",hvals,sep=":")), col=1:4, lty=1)
dev.off()

sapply(hvals, basic_cv, x_num = ech_num)
