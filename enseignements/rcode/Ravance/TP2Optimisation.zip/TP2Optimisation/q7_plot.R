rm(list=ls())
load("resultsq7.rda")

plot(NA, xlim=c(0, max(nvals_num)), ylim=range(results_mat))
lines(nvals_num, rowMeans(results_mat))
lines(nvals_num, nvals_num**(-1/5), col="red")
